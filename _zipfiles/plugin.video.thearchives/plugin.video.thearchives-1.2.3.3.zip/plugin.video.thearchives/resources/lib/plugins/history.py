import json

from ..plugin import Plugin
from resources.lib.util.history_ui import decode_payload, get_store, storage_item


def _message_item(title, summary):
    return {
        "type": "plugin",
        "title": title,
        "summary": summary,
    }


class History(Plugin):
    name = "private history"
    priority = 250

    def get_list(self, url):
        if not url.startswith("history/"):
            return False

        kind = url.split("/", 1)[1]
        kind_map = {
            "favorites": ("favorite", "[COLOR gold][B]No Private Favorites Yet[/B][/COLOR]"),
            "in_progress": ("progress", "[COLOR khaki][B]No Private Progress Yet[/B][/COLOR]"),
            "watched": ("watched", "[COLOR lime][B]No Private Watched History Yet[/B][/COLOR]"),
        }
        if kind not in kind_map:
            return False

        store_kind, empty_title = kind_map[kind]
        items = get_store().list_items(store_kind)
        if not items:
            items = [_message_item(empty_title, "Items will appear here after you use the private history and favorites actions.")]
        return json.dumps({"items": items})

    def routes(self, plugin):
        @plugin.route("/history/add_favorite/<path:payload>")
        def add_favorite(payload):
            item = decode_payload(payload)
            get_store().set_favorite(item, True)
            _notify("Private Favorites", "Added")
            _refresh()

        @plugin.route("/history/remove_favorite/<path:payload>")
        def remove_favorite(payload):
            item = decode_payload(payload)
            get_store().set_favorite(item, False)
            _notify("Private Favorites", "Removed")
            _refresh()

        @plugin.route("/history/toggle_favorite/<path:payload>")
        def toggle_favorite(payload):
            item = decode_payload(payload)
            enabled = get_store().toggle_favorite(item)
            _notify("Private Favorites", "Added" if enabled else "Removed")
            _refresh()

        @plugin.route("/history/mark_watched/<path:payload>")
        def mark_watched(payload):
            item = decode_payload(payload)
            get_store().mark_watched(item)
            _notify("Private History", "Marked watched")
            _refresh()

        @plugin.route("/history/mark_unwatched/<path:payload>")
        def mark_unwatched(payload):
            item = decode_payload(payload)
            get_store().mark_unwatched(item)
            _notify("Private History", "Marked unwatched")
            _refresh()

        @plugin.route("/history/clear_progress/<path:payload>")
        def clear_progress(payload):
            item = decode_payload(payload)
            get_store().clear_progress(item)
            _notify("Private Progress", "Cleared")
            _refresh()


class HistoryPlayer:
    def __init__(self, item):
        import xbmc

        class _Player(xbmc.Player):
            pass

        self.player = _Player()
        self.item = storage_item(item)
        self.store = get_store()

    def _choose_resume_action(self, state):
        try:
            import xbmcaddon
            import xbmcgui

            value = xbmcaddon.Addon().getSetting("resume.playback.popup")
            if str(value or "true").lower() != "true":
                return 1
            progress = int(round(float(state.get("resume_point") or 0)))
            selection = xbmcgui.Dialog().yesnocustom(
                "Resume playback",
                "Choose playback position",
                "Close",
                nolabel="Restart",
                yeslabel="Resume from %d%%" % progress,
            )
            return -1 if selection == 2 else selection
        except Exception as e:
            try:
                import xbmc
                xbmc.log("[TheArchives] Resume choice dialog error: %s" % e, xbmc.LOGERROR)
            except Exception:
                pass
            return 1

    def play(self, url, list_item):
        state = self.store.get_state(self.item)
        start_target = float(self._manual_intro_skip_seconds())
        if state["resume_point"] > 0:
            action = self._choose_resume_action(state)
            if action < 0:
                return True
            if action == 1:
                start_target = float(state.get("curr_time") or 0.0)
                if start_target <= 0:
                    start_target = (float(state.get("resume_point") or 0.0) / 100.0) * float(state.get("total_time") or 0.0)
        if start_target > 0:
            try:
                list_item.setProperty("StartOffset", str(float(start_target)))
            except Exception:
                pass
        self.player.play(url, list_item)
        self._monitor(start_target)
        return True

    def _manual_intro_skip_seconds(self):
        try:
            import xbmcaddon

            enabled = xbmcaddon.Addon().getSetting("debrid.intro.skip.manual.enabled")
            if str(enabled or "true").lower() != "true":
                return 0
            value = xbmcaddon.Addon().getSetting("debrid.intro.skip.seconds")
            return max(0, int(float(value or 0)))
        except Exception as e:
            try:
                import xbmc
                xbmc.log("[TheArchives] Intro skip setting error: %s" % e, xbmc.LOGERROR)
            except Exception:
                pass
            return 0

    def _introdb_enabled(self):
        try:
            import xbmcaddon

            return str(xbmcaddon.Addon().getSetting("introdb.enabled") or "false").lower() == "true"
        except Exception:
            return False

    def _introdb_segments(self, total_time):
        if not self._introdb_enabled() or total_time <= 0:
            return {}
        try:
            from resources.lib.util.introdb import lookup_segments

            return lookup_segments(self.item, int(float(total_time) * 1000.0))
        except Exception as e:
            try:
                import xbmc
                xbmc.log("[TheArchives] TheIntroDB lookup error: %s" % e, xbmc.LOGERROR)
            except Exception:
                pass
            return {}

    def _skip_introdb_segments(self, segments, skipped, current_time, total_time):
        for segment_type in ("intro", "credits"):
            for index, segment in enumerate(segments.get(segment_type) or []):
                key = "%s:%d" % (segment_type, index)
                if key in skipped:
                    continue
                start = float(segment.get("start") or 0.0)
                end = segment.get("end")
                if current_time < start:
                    continue
                if end is not None and current_time >= float(end):
                    skipped.add(key)
                    continue
                target = float(end) if end is not None else max(0.0, total_time - 1.0)
                skipped.add(key)
                if target > current_time + 0.25:
                    self.player.seekTime(min(target, max(0.0, total_time - 0.25)))
                    return True
        return False

    def _apply_start_seek(self, target, timeout_ms=15000):
        target = max(0.0, float(target or 0.0))
        if target <= 0:
            return False
        try:
            import xbmc

            waited = 0
            while waited < timeout_ms and self.player.isPlaying():
                try:
                    total_time = float(self.player.getTotalTime())
                    current_time = float(self.player.getTime())
                except Exception:
                    total_time = 0.0
                    current_time = 0.0
                if total_time > 0:
                    target = min(target, max(0.0, total_time - 1.0))
                    if current_time + 1.0 < target:
                        self.player.seekTime(target)
                        return True
                    return False
                xbmc.sleep(250)
                waited += 250
        except Exception as e:
            try:
                import xbmc
                xbmc.log("[TheArchives] Playback start seek error: %s" % e, xbmc.LOGERROR)
            except Exception:
                pass
        return False

    def _maybe_autoplay_next_episode(self, best_percent):
        if best_percent < 95.0 or str(self.item.get("content") or "").lower() != "episode":
            return False
        try:
            from resources.lib.util.debrid_autoplay import launch_next_episode

            return bool(launch_next_episode(self.item))
        except Exception as e:
            try:
                import xbmc
                xbmc.log("[TheArchives] Next debrid episode launch error: %s" % e, xbmc.LOGERROR)
            except Exception:
                pass
            return False

    def _monitor(self, start_target=0.0):
        try:
            import xbmc

            waited = 0
            while waited < 30000 and not self.player.isPlaying():
                xbmc.sleep(250)
                waited += 250

            if not self.player.isPlaying():
                return

            self._apply_start_seek(start_target)
            last_time = 0.0
            total_time = 0.0
            best_percent = 0.0
            introdb_segments = None
            introdb_skipped = set()
            while self.player.isPlaying():
                xbmc.sleep(1000)
                try:
                    total_time = float(self.player.getTotalTime())
                    last_time = float(self.player.getTime())
                except Exception:
                    continue
                if total_time <= 0:
                    continue
                if introdb_segments is None:
                    introdb_segments = self._introdb_segments(total_time)
                if introdb_segments:
                    self._skip_introdb_segments(
                        introdb_segments, introdb_skipped, last_time, total_time
                    )
                best_percent = max(best_percent, round((last_time / total_time) * 100.0, 1))

            if total_time <= 0:
                return
            if best_percent >= 90.0:
                self.store.mark_watched(self.item)
                self._maybe_autoplay_next_episode(best_percent)
            else:
                self.store.set_progress(self.item, last_time, total_time)
        except Exception as e:
            try:
                import xbmc as _xbmc
                _xbmc.log(f"[TheArchives] HistoryPlayer._monitor error: {e}", _xbmc.LOGERROR)
            except Exception:
                pass
            return


def _notify(heading, message):
    try:
        import xbmcaddon
        import xbmcgui

        addon = xbmcaddon.Addon()
        xbmcgui.Dialog().notification(heading, message, addon.getAddonInfo("icon"), 2500, sound=False)
    except Exception:
        pass


def _refresh():
    try:
        import xbmc

        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
